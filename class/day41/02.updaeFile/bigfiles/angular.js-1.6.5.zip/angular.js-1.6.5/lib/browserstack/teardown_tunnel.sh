#!/bin/bash

set -e -o pipefail


echo "Shutting down Browserstack tunnel"
echo "TODO: implement me"
exit 1